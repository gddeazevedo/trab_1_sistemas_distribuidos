package demos;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

class BalanceadorCarga {
    private int porta;
    private int[] portasServidores;
    private ServerSocket serverSocket;
    private LinkedBlockingQueue<RequisicaoEscrita> filaEscrita;
    private ReentrantLock lockConsistencia;
    
    class RequisicaoEscrita {
        Socket socket;
        int x, y;
        
        public RequisicaoEscrita(Socket socket, int x, int y) {
            this.socket = socket;
            this.x = x;
            this.y = y;
        }
    }
    
    public BalanceadorCarga(int porta, int[] portasServidores) {
        this.porta = porta;
        this.portasServidores = portasServidores;
        this.filaEscrita = new LinkedBlockingQueue<>();
        this.lockConsistencia = new ReentrantLock();
        
        // Thread para processar fila de escrita
        new Thread(new ProcessadorFilaEscrita()).start();
    }
    
    private boolean verificarConsistencia() {
        Set<Integer> contagens = new HashSet<>();
        
        for (int portaServidor : portasServidores) {
            try {
                Socket s = new Socket("localhost", portaServidor);
                PrintWriter out = new PrintWriter(s.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                
                out.println("CONTAR");
                String resp = in.readLine();
                contagens.add(Integer.parseInt(resp));
                
                s.close();
            } catch (Exception e) {
                System.out.println("[Balanceador] Erro ao verificar consistência no servidor " + portaServidor + ": " + e.getMessage());
                return false;
            }
        }
        
        return contagens.size() == 1;
    }
    
    private int calcularMDC(int x, int y) {
        while (y != 0) {
            int temp = y;
            y = x % y;
            x = temp;
        }
        return x;
    }
    
    private void replicarParaOutros(int portaOrigem, int x, int y, int mdc) {
        for (int porta : portasServidores) {
            if (porta != portaOrigem) {
                try {
                    Socket s = new Socket("localhost", porta);
                    PrintWriter out = new PrintWriter(s.getOutputStream(), true);
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    
                    out.println("REPLICACAO|" + x + "|" + y + "|" + mdc);
                    in.readLine();
                    
                    s.close();
                } catch (Exception e) {
                    System.out.println("[Balanceador] Erro ao replicar para porta " + porta + ": " + e.getMessage());
                }
            }
        }
    }
    
    class ProcessadorFilaEscrita implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    if (!filaEscrita.isEmpty()) {
                        lockConsistencia.lock();
                        try {
                            if (verificarConsistencia()) {
                                RequisicaoEscrita req = filaEscrita.take();
                                executarEscrita(req);
                            } else {
                                System.out.println("[Balanceador] Aguardando consistência...");
                                Thread.sleep(100);
                            }
                        } finally {
                            lockConsistencia.unlock();
                        }
                    } else {
                        Thread.sleep(10);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    private void executarEscrita(RequisicaoEscrita req) {
        Random rand = new Random();
        int portaEscolhida = portasServidores[rand.nextInt(portasServidores.length)];
        
        try {
            Socket s = new Socket("localhost", portaEscolhida);
            PrintWriter out = new PrintWriter(s.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            
            out.println("ESCRITA|" + req.x + "|" + req.y);
            in.readLine();
            s.close();
            
            int mdc = calcularMDC(req.x, req.y);
            replicarParaOutros(portaEscolhida, req.x, req.y, mdc);
            
            PrintWriter clientOut = new PrintWriter(req.socket.getOutputStream(), true);
            clientOut.println("OK");
            req.socket.close();
            
            System.out.println("[Balanceador] Escrita processada: " + req.x + ", " + req.y);
            
        } catch (Exception e) {
            System.out.println("[Balanceador] Erro na escrita: " + e.getMessage());
        }
    }
    
    private void processarLeitura(Socket socket) {
        try {
            List<String> respostas = new ArrayList<>();
            
            for (int portaServidor : portasServidores) {
                try {
                    Socket s = new Socket("localhost", portaServidor);
                    PrintWriter out = new PrintWriter(s.getOutputStream(), true);
                    BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    
                    out.println("LEITURA");
                    String resp = in.readLine();
                    respostas.add(resp);
                    
                    s.close();
                } catch (Exception e) {
                    System.out.println("[Balanceador] Erro ao ler servidor " + portaServidor + ": " + e.getMessage());
                }
            }
            
            PrintWriter clientOut = new PrintWriter(socket.getOutputStream(), true);
            clientOut.println(String.join(",", respostas));
            socket.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    class ThreadRequisicao extends Thread {
        private Socket socket;
        
        public ThreadRequisicao(Socket socket) {
            this.socket = socket;
        }
        
        @Override
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String dados = in.readLine();
                String[] partes = dados.split("\\|");
                String tipo = partes[0];
                
                if (tipo.equals("ESCRITA")) {
                    int x = Integer.parseInt(partes[1]);
                    int y = Integer.parseInt(partes[2]);
                    filaEscrita.put(new RequisicaoEscrita(socket, x, y));
                } else if (tipo.equals("LEITURA")) {
                    processarLeitura(socket);
                }
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void iniciar() {
        try {
            serverSocket = new ServerSocket(porta);
            System.out.println("[Balanceador] Iniciado na porta " + porta);
            
            while (true) {
                Socket socket = serverSocket.accept();
                new ThreadRequisicao(socket).start();
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        int[] portasServidores = {5001, 5002, 5003};
        BalanceadorCarga balanceador = new BalanceadorCarga(5000, portasServidores);
        balanceador.iniciar();
    }
}