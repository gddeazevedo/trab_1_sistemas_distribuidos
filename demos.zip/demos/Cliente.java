package demos;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.locks.*;

class Cliente {
    private int id;
    private int portaBalanceador;
    private String arquivoLog;
    private ReentrantLock lockLog;
    private Random random;
    
    public Cliente(int id, int portaBalanceador) {
        this.id = id;
        this.portaBalanceador = portaBalanceador;
        this.arquivoLog = "cliente_" + id + "_log.txt";
        this.lockLog = new ReentrantLock();
        this.random = new Random();
        
        try {
            File f = new File(arquivoLog);
            if (!f.exists()) {
                f.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void registrarLog(int x, int y) {
        try {
            FileWriter fw = new FileWriter(arquivoLog, true);
            fw.write(x + "," + y + "\n");
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void enviarEscrita() {
        int x = 2 + random.nextInt(999999);
        int y = 2 + random.nextInt(999999);
        
        registrarLog(x, y);
        
        try {
            Socket socket = new Socket("localhost", portaBalanceador);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            
            out.println("ESCRITA|" + x + "|" + y);
            in.readLine();
            socket.close();
            
            System.out.println("[Cliente " + id + "] Enviou escrita: " + x + ", " + y);
            
        } catch (Exception e) {
            System.out.println("[Cliente " + id + "] Erro ao enviar escrita: " + e.getMessage());
        }
    }
    
    private void enviarLeitura() {
        try {
            Socket socket = new Socket("localhost", portaBalanceador);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            
            out.println("LEITURA");
            String resp = in.readLine();
            socket.close();
            
            System.out.println("[Cliente " + id + "] Leitura recebida: " + resp);
            
        } catch (Exception e) {
            System.out.println("[Cliente " + id + "] Erro ao enviar leitura: " + e.getMessage());
        }
    }
    
    public void executar() {
        System.out.println("[Cliente " + id + "] Iniciado");
        
        while (true) {
            try {
                // Sorteia tipo de requisição
                if (random.nextDouble() < 0.5) {
                    enviarEscrita();
                } else {
                    enviarLeitura();
                }
                
                // Dorme entre 20 e 50ms
                Thread.sleep(20 + random.nextInt(31));
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Uso: java Cliente <id>");
            return;
        }
        
        int id = Integer.parseInt(args[0]);
        Cliente cliente = new Cliente(id, 5000);
        cliente.executar();
    }
}
