import java.io.*;
import java.net.*;
import java.util.*;

class LoadBalancer {
    private int porta;
    private int[] portasServidores;
    private ServerSocket serverSocket;
    private int proximoServidor = 0; // Para round-robin
    
    public LoadBalancer(int porta, int[] portasServidores) {
        this.porta = porta;
        this.portasServidores = portasServidores;
    }
    
    private int escolherServidor() {
        // Round-robin simples
        int servidor = portasServidores[proximoServidor];
        proximoServidor = (proximoServidor + 1) % portasServidores.length;
        return servidor;
    }
    
    private void repassarRequisicao(Socket clientSocket, String requisicao) {
        int portaServidor = escolherServidor();
        
        try {
            // Conecta ao servidor escolhido
            Socket servidorSocket = new Socket("localhost", portaServidor);
            PrintWriter outServidor = new PrintWriter(servidorSocket.getOutputStream(), true);
            BufferedReader inServidor = new BufferedReader(new InputStreamReader(servidorSocket.getInputStream()));
            
            // Envia requisição ao servidor
            outServidor.println(requisicao);
            System.out.println("[Balanceador] Repassando para servidor " + portaServidor + ": " + requisicao);
            
            // Recebe resposta do servidor
            String resposta = inServidor.readLine();
            
            // Envia resposta de volta ao cliente
            PrintWriter outCliente = new PrintWriter(clientSocket.getOutputStream(), true);
            outCliente.println(resposta);
            
            // Fecha conexões
            servidorSocket.close();
            clientSocket.close();
            
            System.out.println("[Balanceador] Resposta enviada ao cliente: " + resposta);
            
        } catch (Exception e) {
            System.out.println("[Balanceador] Erro ao repassar requisição: " + e.getMessage());
            try {
                PrintWriter outCliente = new PrintWriter(clientSocket.getOutputStream(), true);
                outCliente.println("ERRO");
                clientSocket.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
    
    class ThreadRequisicao extends Thread {
        private Socket socket;
        
        public ThreadRequisicao(Socket socket) {
            this.socket = socket;
        }
        
        @Override
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String requisicao = in.readLine();
                
                if (requisicao != null) {
                    repassarRequisicao(socket, requisicao);
                }
                
            } catch (Exception e) {
                System.out.println("[Balanceador] Erro ao processar requisição: " + e.getMessage());
            }
        }
    }
    
    public void iniciar() {
        try {
            serverSocket = new ServerSocket(porta);
            System.out.println("[Balanceador] Iniciado na porta " + porta);
            System.out.println("[Balanceador] Servidores disponíveis: " + Arrays.toString(portasServidores));
            
            while (true) {
                Socket socket = serverSocket.accept();
                new ThreadRequisicao(socket).start();
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        int[] portasServidores = {5001, 5002, 5003};
        LoadBalancer balanceador = new LoadBalancer(5000, portasServidores);
        balanceador.iniciar();
    }
}