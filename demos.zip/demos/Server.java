import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

class Server {
    private int porta;
    private int[] portasOutrosServeres;
    private ServerSocket serverSocket;
    private List<ParMDC> dados;
    private ReentrantLock lock;
    private LinkedBlockingQueue<OperacaoEscrita> filaEscrita;
    private String nomeArquivo;
    
    class ParMDC {
        int x, y, mdc;
        
        public ParMDC(int x, int y, int mdc) {
            this.x = x;
            this.y = y;
            this.mdc = mdc;
        }
        
        @Override
        public String toString() {
            return "(" + x + "," + y + "," + mdc + ")";
        }
    }
    
    class OperacaoEscrita {
        int x, y;
        
        public OperacaoEscrita(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
    
    public Server(int porta, int[] portasOutrosServeres) {
        this.porta = porta;
        this.portasOutrosServeres = portasOutrosServeres;
        this.dados = Collections.synchronizedList(new ArrayList<>());
        this.lock = new ReentrantLock();
        this.filaEscrita = new LinkedBlockingQueue<>();
        this.nomeArquivo = "servidor_" + porta + ".txt";
        
        // Carrega dados do arquivo na inicialização
        carregarDados();
        
        // Thread para processar fila de escrita
        new Thread(new ProcessadorFilaEscrita()).start();
    }
    
    private void carregarDados() {
        File arquivo = new File(nomeArquivo);
        if (!arquivo.exists()) {
            System.out.println("[Server " + porta + "] Arquivo não existe, começando vazio");
            return;
        }
        
        try (BufferedReader reader = new BufferedReader(new FileReader(arquivo))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split("\\|");
                if (partes.length == 3) {
                    int x = Integer.parseInt(partes[0]);
                    int y = Integer.parseInt(partes[1]);
                    int mdc = Integer.parseInt(partes[2]);
                    dados.add(new ParMDC(x, y, mdc));
                }
            }
            System.out.println("[Server " + porta + "] Carregados " + dados.size() + " registros do arquivo");
        } catch (IOException e) {
            System.out.println("[Server " + porta + "] Erro ao carregar dados: " + e.getMessage());
        }
    }
    
    private void salvarNoArquivo(int x, int y, int mdc) {
        try (FileWriter fw = new FileWriter(nomeArquivo, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(x + "|" + y + "|" + mdc);
            System.out.println("[Server " + porta + "] Salvo no arquivo: " + x + "|" + y + "|" + mdc);
        } catch (IOException e) {
            System.out.println("[Server " + porta + "] Erro ao salvar no arquivo: " + e.getMessage());
        }
    }
    
    private int calcularMDC(int x, int y) {
        while (y != 0) {
            int temp = y;
            y = x % y;
            x = temp;
        }
        return Math.abs(x);
    }
    
    private boolean verificarConsistencia() {
        Set<Integer> contagens = new HashSet<>();
        contagens.add(dados.size()); // Adiciona contagem local
        
        for (int portaOutro : portasOutrosServeres) {
            try {
                Socket s = new Socket("localhost", portaOutro);
                s.setSoTimeout(1000); // Timeout de 1 segundo
                PrintWriter out = new PrintWriter(s.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                
                out.println("CONTAR");
                String resp = in.readLine();
                contagens.add(Integer.parseInt(resp));
                
                s.close();
            } catch (Exception e) {
                System.out.println("[Server " + porta + "] Server " + portaOutro + " não acessível");
                return false; // Se não conseguir acessar algum servidor, não há consistência
            }
        }
        
        return contagens.size() == 1; // Todos têm a mesma contagem
    }
    
    private void replicarParaOutros(int x, int y, int mdc) {
        for (int portaOutro : portasOutrosServeres) {
            try {
                Socket s = new Socket("localhost", portaOutro);
                PrintWriter out = new PrintWriter(s.getOutputStream(), true);
                BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
                
                out.println("REPLICACAO|" + x + "|" + y + "|" + mdc);
                in.readLine(); // Aguarda confirmação
                
                s.close();
                System.out.println("[Server " + porta + "] Replicado para servidor " + portaOutro);
            } catch (Exception e) {
                System.out.println("[Server " + porta + "] Erro ao replicar para " + portaOutro + ": " + e.getMessage());
            }
        }
    }
    
    class ProcessadorFilaEscrita implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    if (!filaEscrita.isEmpty()) {
                        lock.lock();
                        try {
                            if (verificarConsistencia()) {
                                OperacaoEscrita op = filaEscrita.take();
                                executarEscrita(op.x, op.y);
                            } else {
                                System.out.println("[Server " + porta + "] Aguardando consistência...");
                                Thread.sleep(100);
                            }
                        } finally {
                            lock.unlock();
                        }
                    } else {
                        Thread.sleep(10);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    private void executarEscrita(int x, int y) {
        int mdc = calcularMDC(x, y);
        
        // Salva no arquivo local
        salvarNoArquivo(x, y, mdc);
        
        // Adiciona na memória
        dados.add(new ParMDC(x, y, mdc));
        
        System.out.println("[Server " + porta + "] Escrita local: " + x + ", " + y + " -> MDC: " + mdc);
        
        // Replica para outros servidores
        replicarParaOutros(x, y, mdc);
    }
    
    class ThreadRequisicao extends Thread {
        private Socket socket;
        
        public ThreadRequisicao(Socket socket) {
            this.socket = socket;
        }
        
        @Override
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                
                String requisicao = in.readLine();
                String[] partes = requisicao.split("\\|");
                String tipo = partes[0];
                
                if (tipo.equals("ESCRITA")) {
                    int x = Integer.parseInt(partes[1]);
                    int y = Integer.parseInt(partes[2]);
                    
                    // Adiciona à fila de escrita
                    filaEscrita.put(new OperacaoEscrita(x, y));
                    out.println("OK");
                    
                } else if (tipo.equals("LEITURA")) {
                    lock.lock();
                    try {
                        StringBuilder sb = new StringBuilder();
                        for (ParMDC par : dados) {
                            sb.append(par.toString()).append(";");
                        }
                        String resposta = sb.length() > 0 ? sb.toString() : "VAZIO";
                        out.println(resposta);
                        System.out.println("[Server " + porta + "] Leitura: " + dados.size() + " itens");
                    } finally {
                        lock.unlock();
                    }
                    
                } else if (tipo.equals("REPLICACAO")) {
                    int x = Integer.parseInt(partes[1]);
                    int y = Integer.parseInt(partes[2]);
                    int mdc = Integer.parseInt(partes[3]);
                    
                    lock.lock();
                    try {
                        // Salva no arquivo local
                        salvarNoArquivo(x, y, mdc);
                        
                        // Adiciona na memória
                        dados.add(new ParMDC(x, y, mdc));
                        System.out.println("[Server " + porta + "] Replicação recebida e salva: " + x + ", " + y + " -> MDC: " + mdc);
                    } finally {
                        lock.unlock();
                    }
                    out.println("OK");
                    
                } else if (tipo.equals("CONTAR")) {
                    out.println(String.valueOf(dados.size()));
                    
                } else {
                    out.println("COMANDO_DESCONHECIDO");
                }
                
                socket.close();
                
            } catch (Exception e) {
                System.out.println("[Server " + porta + "] Erro ao processar requisição: " + e.getMessage());
            }
        }
    }
    
    public void iniciar() {
        try {
            serverSocket = new ServerSocket(porta);
            System.out.println("[Server " + porta + "] Iniciado e aguardando conexões...");
            System.out.println("[Server " + porta + "] Arquivo de dados: " + nomeArquivo);
            
            while (true) {
                Socket socket = serverSocket.accept();
                new ThreadRequisicao(socket).start();
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Uso: java Server <porta> [porta_outro1] [porta_outro2] ...");
            return;
        }
        
        int porta = Integer.parseInt(args[0]);
        int[] portasOutros = new int[args.length - 1];
        
        for (int i = 1; i < args.length; i++) {
            portasOutros[i - 1] = Integer.parseInt(args[i]);
        }
        
        Server servidor = new Server(porta, portasOutros);
        servidor.iniciar();
    }
}