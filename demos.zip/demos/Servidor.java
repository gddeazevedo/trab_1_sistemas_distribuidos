package demos;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.locks.*;

class Servidor {
    private int id;
    private int porta;
    private String arquivo;
    private ReentrantLock lockArquivo;
    private ServerSocket serverSocket;
    
    public Servidor(int id, int porta) {
        this.id = id;
        this.porta = porta;
        this.arquivo = "servidor_" + id + ".txt";
        this.lockArquivo = new ReentrantLock();
        
        try {
            File f = new File(arquivo);
            if (!f.exists()) {
                f.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private int calcularMDC(int x, int y) {
        while (y != 0) {
            int temp = y;
            y = x % y;
            x = temp;
        }
        return x;
    }
    
    private int contarLinhas() {
        lockArquivo.lock();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(arquivo));
            int linhas = 0;
            while (reader.readLine() != null) {
                linhas++;
            }
            reader.close();
            return linhas;
        } catch (IOException e) {
            e.printStackTrace();
            return 0;
        } finally {
            lockArquivo.unlock();
        }
    }
    
    class ThreadEscrita extends Thread {
        private int x, y;
        
        public ThreadEscrita(int x, int y) {
            this.x = x;
            this.y = y;
        }
        
        @Override
        public void run() {
            try {
                // Dorme entre 100 e 200ms
                Thread.sleep(100 + new Random().nextInt(101));
                
                int mdc = calcularMDC(x, y);
                String linha = "O MDC entre " + x + " e " + y + " é " + mdc + "\n";
                
                lockArquivo.lock();
                try {
                    FileWriter fw = new FileWriter(arquivo, true);
                    fw.write(linha);
                    fw.close();
                } finally {
                    lockArquivo.unlock();
                }
                
                System.out.println("[Servidor " + id + "] Escrito: O MDC entre " + x + " e " + y + " é " + mdc);
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    class ThreadLeitura extends Thread {
        @Override
        public void run() {
            int linhas = contarLinhas();
            System.out.println("[Servidor " + id + "] Arquivo possui " + linhas + " linhas");
        }
    }
    
    class ThreadRequisicao extends Thread {
        private Socket socket;
        
        public ThreadRequisicao(Socket socket) {
            this.socket = socket;
        }
        
        @Override
        public void run() {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                
                String dados = in.readLine();
                String[] partes = dados.split("\\|");
                String tipo = partes[0];
                
                if (tipo.equals("ESCRITA")) {
                    int x = Integer.parseInt(partes[1]);
                    int y = Integer.parseInt(partes[2]);
                    
                    ThreadEscrita threadEscrita = new ThreadEscrita(x, y);
                    threadEscrita.start();
                    threadEscrita.join();
                    
                    out.println("OK");
                    
                } else if (tipo.equals("LEITURA")) {
                    ThreadLeitura threadLeitura = new ThreadLeitura();
                    threadLeitura.start();
                    threadLeitura.join();
                    
                    int linhas = contarLinhas();
                    out.println(linhas);
                    
                } else if (tipo.equals("REPLICACAO")) {
                    int x = Integer.parseInt(partes[1]);
                    int y = Integer.parseInt(partes[2]);
                    int mdc = Integer.parseInt(partes[3]);
                    
                    String linha = "O MDC entre " + x + " e " + y + " é " + mdc + "\n";
                    
                    lockArquivo.lock();
                    try {
                        FileWriter fw = new FileWriter(arquivo, true);
                        fw.write(linha);
                        fw.close();
                    } finally {
                        lockArquivo.unlock();
                    }
                    
                    System.out.println("[Servidor " + id + "] Replicado: O MDC entre " + x + " e " + y + " é " + mdc);
                    out.println("OK");
                    
                } else if (tipo.equals("CONTAR")) {
                    int linhas = contarLinhas();
                    out.println(linhas);
                }
                
                socket.close();
                
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void iniciar() {
        try {
            serverSocket = new ServerSocket(porta);
            System.out.println("[Servidor " + id + "] Iniciado na porta " + porta);
            
            while (true) {
                Socket socket = serverSocket.accept();
                new ThreadRequisicao(socket).start();
            }
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Uso: java Servidor <id> <porta>");
            return;
        }
        
        int id = Integer.parseInt(args[0]);
        int porta = Integer.parseInt(args[1]);
        
        Servidor servidor = new Servidor(id, porta);
        servidor.iniciar();
    }
}